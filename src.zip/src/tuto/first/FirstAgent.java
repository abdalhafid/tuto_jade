package tuto.first;
import jade.core.Agent;
public class FirstAgent extends Agent
{
	protected void setup()
	{
		System.out.println("Hello Jade !!");
		System.out.println("Je suis le premier Agent");
	}
}